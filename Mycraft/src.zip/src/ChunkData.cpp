//
//  ChunkData.cpp
//  MineCraft
//
//  Created by apple on 17/11/14.
//  Copyright © 2017年 apple. All rights reserved.
//

#include "ChunkData.hpp"
#define SOIL_THICKNESS 5

inline void SubChunk::setPathHistory(int direction){
    pathHistory |= direction;
}

inline int SubChunk::getPathHistory(){
    return pathHistory;
}

bool SubChunk::inFrustum(int x, int y, int z){
    int chunkCoordinate[8][3] =
    {0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1,
        1, 0 ,0, 1, 0, 1, 1, 1, 0, 1, 1, 1};
    int tmpx, tmpy, tmpz;
    for(int i = 0; i < 8; i++)
    {
        tmpx = x+chunkCoordinate[i][0];
        tmpy = y+chunkCoordinate[i][1];
        tmpz = z+chunkCoordinate[i][2];
        for(int j = 0; j < 6; j++)
        {
            if(frustumPlanes[i][0]*tmpx+frustumPlanes[i][1]*tmpy+frustumPlanes[i][2]*tmpz+
               frustumPlanes[i][3] > 0)
            return true;
        }
    }
    return false;
}

inline void SubChunk::updateNeighbor(SubChunk* dir[6]){
    xNeg = dir[0];
    xPos = dir[1];
    zNeg = dir[2];
    zPos = dir[3];
    yNeg = dir[4];
    yPos = dir[5];
}

void SubChunk::updateQuads(){
    char xNegType;
    char xPosType;
    char zNegType;
    char zPosType;
    char yNegType;
    char yPosType;
    
    Quads.clear();
    Quads.reserve(VECTOR_OFFSET);
    
    if(isEmpty)
        return;
    
    for(int i = 0; i < 16; i++)
    {
        for(int j = 0; j <16; j++)
        {
            for(int k = 0; k <16; k++)
            {
                if(BlockType[i][j][k] == (char)AIR)
                continue;
                
                xNegType = (j == 0)? ((xNeg)? xNeg->BlockType[i][15][k]: BOUND) : BlockType[i][j-1][k];
                xPosType = (j == 15)? ((xPos)? xPos->BlockType[i][0][k]: BOUND) : BlockType[i][j+1][k];
                zNegType = (k == 0)? ((zNeg)? zNeg->BlockType[i][j][15]: BOUND) : BlockType[i][j][k-1];
                zPosType = (k == 15)? ((zPos)? zPos->BlockType[i][j][0]: BOUND) : BlockType[i][j][k+1];
                yNegType = (i == 0)? ((yNeg)? yNeg->BlockType[15][j][k]: BOUND) : BlockType[i-1][j][k];
                yPosType = (i == 15)? ((yPos)? yPos->BlockType[0][j][k]: BOUND) : BlockType[i+1][j][k];
                
                if(yPosType & 0x80) //up
                {
                    addVertices(YPOS, i, j, k);
                }
                if(yNegType & 0x80) //down
                {
                    addVertices(YNEG, i, j, k);
                }
                if(xPosType & 0x80) //right
                {
                    addVertices(XPOS, i, j, k);
                }
                if(xNegType & 0x80) //left
                {
                    addVertices(XNEG, i, j, k);
                }
                if(zPosType & 0x80) //front
                {
                    addVertices(ZPOS, i, j, k);
                }
                if(zNegType & 0x80) //behind
                {
                    addVertices(ZNEG, i, j, k);
                }
            }
        }
    }
    if(Quads.size() > 0)
        bufferObject.updateBuffer(&Quads[0], Quads.size());
}

void SubChunk::updateQuads(int side)
{
    if(side == LEFT)
    {
        SubChunk *neighbor = xNeg;
        for(int i = 0; i < 16; i++)
        {
            for(int j =0; j < 16; j++)
            {
                if(neighbor->BlockType[i][15][j] & 0x80)
                {
                    addVertices(XNEG, i, 0, j);
                }
            }
        }
    }
    else if(side == RIGHT)
    {
        SubChunk *neighbor = xPos;
        for(int i = 0; i < 16; i++)
        {
            for(int j =0; j < 16; j++)
            {
                if(neighbor->BlockType[i][0][j] & 0x80) //left
                {
                    addVertices(XPOS, i, 15, j);
                }
            }
        }
    }
    else if(side == BEHIND)
    {
        SubChunk *neighbor = zNeg;
        for(int i = 0; i < 16; i++)
        {
            for(int j =0; j < 16; j++)
            {
                if(neighbor->BlockType[i][j][15] & 0x80) //left
                {
                    addVertices(ZNEG, i, j, 0);
                }
            }
        }
    }
    else if(side == FRONT)
    {
        SubChunk *neighbor = zPos;
        for(int i = 0; i < 16; i++)
        {
            for(int j =0; j < 16; j++)
            {
                if(neighbor->BlockType[i][j][0] & 0x80) //left
                {
                    addVertices(ZPOS, i, j, 15);
                }
            }
        }
    }
}

void SubChunk::addVertices(int dir, int y, int x, int z)
{
    if(dir < XNEG || dir > YPOS)
        return;
    else{
        if(Quads.size()+QUAD_SIZE >= Quads.capacity())
        {
            Quads.reserve(Quads.size()+VECTOR_OFFSET);
        }
        float tmp[48];
        memcpy(tmp, vertex[dir], 48*sizeof(float));
        for(int m = 0; m < 48; m = m+8)
        {
            tmp[m] += x+this->x;
            tmp[m+1] += y+this->y;
            tmp[m+2] += z+this->z;
        }
        Quads.insert(Quads.end(), tmp, tmp+48);
    }
}

void SubChunk::adjBlocksEnqueue(){
    
    if((adjVisibility&LEFT) != 0 && xNeg != NULL && xNeg->pathHistory == 0 && (pathHistory & RIGHT) == 0 /*&& inFrustum(x-16, y, z)*/)
    {
        xNeg->pathHistory |= LEFT|pathHistory;
        scanQueue.push(xNeg);
    }
    if((adjVisibility&RIGHT) != 0 && xPos != NULL && xPos->pathHistory == 0 && (pathHistory & LEFT) == 0 /*&& inFrustum(x+16, y, z)*/)
    {
        xPos->pathHistory |= RIGHT|pathHistory;
        scanQueue.push(xPos);
    }
    if((adjVisibility&BEHIND) != 0 && zNeg != NULL && zNeg->pathHistory == 0 && (pathHistory & FRONT) == 0 /*&& inFrustum(x, y, z-16)*/)
    {
        zNeg->pathHistory |= BEHIND|pathHistory;
        scanQueue.push(zNeg);
    }
    if((adjVisibility&FRONT) != 0 && zPos != NULL && zPos->pathHistory == 0 && (pathHistory & BEHIND) == 0 /*&& inFrustum(x, y, z+16)*/)
    {
        zPos->pathHistory |= FRONT|pathHistory;
        scanQueue.push(zPos);
    }
    if((adjVisibility&DOWN) != 0 && yNeg != NULL && yNeg->pathHistory == 0 && (pathHistory & UP) == 0 /*&&inFrustum(x, y-16, z)*/)
    {
        yNeg->pathHistory |= DOWN|pathHistory;
        scanQueue.push(yNeg);
    }
    if((adjVisibility&UP) != 0 && yPos != NULL && yPos->pathHistory == 0 && (pathHistory & DOWN) == 0 /*&&
       inFrustum(x, y+16, z)*/)
    {
        yPos->pathHistory |= UP|pathHistory;
        scanQueue.push(yPos);
    }
}


void SubChunk::updateVisibility(){
    if(count == 4096)
    adjVisibility = NO_DIR;
    else if(count < 256)
    adjVisibility = ALL_DIR;
    else{
        for(int i = 0; i < 16; i++)
        {
            for(int j = 0; j < 16; j++)
            {
                if(BlockType[0][i][j] & 0x80)
                {
                    adjVisibility |= DOWN;
                }
                
                if(BlockType[15][i][j] & 0x80)
                {
                    adjVisibility |= UP;
                }
                
                if(BlockType[i][0][j] & 0x80)
                {
                    adjVisibility |= LEFT;
                }
                
                if(BlockType[i][15][j] & 0x80)
                {
                    adjVisibility |= RIGHT;
                }
                
                if(BlockType[i][j][0] & 0x80)
                {
                    adjVisibility |= BEHIND;
                }
                
                if(BlockType[i][j][15] & 0x80)
                {
                    adjVisibility |= FRONT;
                }
            }
        }
    }
}

inline void SubChunk::setVisibility(int dir){
    adjVisibility |= dir;
}

char SubChunk::removeBlock(int y, int x, int z){
    char type = BlockType[y][x][z];
    BlockType[y][x][z] = AIR;
    if((type&0x80) == 0)
    {
        count--;
        updateQuads();
        if(x == 0 && xNeg != NULL)
        {
            xNeg->addVertices(XPOS, y, 15, z);
            adjVisibility |= LEFT;
        }
        if(x == 15 && xPos != NULL)
        {
            xPos->addVertices(XNEG, y, 0, z);
            adjVisibility |= RIGHT;
        }
        if(z == 0 && zNeg != NULL)
        {
            zNeg->addVertices(ZPOS, y, x, 15);
            adjVisibility |= BEHIND;
        }
        if(z == 15 && zPos != NULL)
        {
            zPos->addVertices(ZNEG, y, x, 0);
            adjVisibility |= FRONT;
        }
        if(y == 0 && yNeg != NULL)
        {
            yNeg->addVertices(YPOS, 15, x, z);
            adjVisibility |= DOWN;
        }
        if(y == 15 && yPos != NULL)
        {
            yPos->addVertices(YNEG, 0, x, z);
            adjVisibility |= UP;
        }
    }
    return type;
}

void SubChunk::placeBlock(char type, int y, int x, int z){
    if(type == (char)AIR)
    {
        return;
    }
    BlockType[y][x][z] = type;
    if((type&0x80) == 0)
    {
        count++;
        updateQuads();
        if(x == 0 || x == 15 || z == 0 || z == 15 || y == 0 || y == 15)
        {
            updateVisibility();
        }
        if(x == 0 && xNeg != NULL)
            xNeg->updateQuads();
        if(x == 15 && xPos != NULL)
            xPos->updateQuads();
        if(z == 0 && zNeg != NULL)
            zNeg->updateQuads();
        if(z == 15 && zPos != NULL)
            zPos->updateQuads();
        if(y == 0 && yNeg != NULL)
            yNeg->updateQuads();
        if(y == 15 && yPos != NULL)
            yPos->updateQuads();
    }
}

void SubChunk::BlockClicked(char type, int y, int x, int z){
    if(BlockType[y][x][z] == (char)AIR)
        placeBlock(type, y, x, z);
    else
    {
        for(int i = 0; i < sizeof(unclickable); i++)
            if(BlockType[y][x][z] == unclickable[i])
                return;
        removeBlock(y, x, z);
    }
}


float Noise(int x, int y){
    int n = x+y*57;
    n = (n<<13)^n;
    return (1.0-((n*(n*n*15731+789221)+1376312589)&0x7fffffff)/1073741824.0);
}

float SmoothedNoise(int x, int y)
{
    float corners = (Noise(x-1, y-1)+Noise(x+1, y-1)+Noise(x-1, y+1)+Noise(x+1, y+1))/16;
    float sides = (Noise(x-1, y)+Noise(x+1, y)+Noise(x, y-1)+Noise(x, y+1))/8;
    float center = Noise(x, y)/4;
    return corners + sides + center;
}

float Interpolate(float a, float b, float x)
{
    float ft = x*M_PI;
    float f = (1-cos(ft))*0.5;
    return a*(1-f)+b*f;
}


float InterpolatedNoise(float x, float y)
{
    int integerX = int(x);
    float fractionalX = x-integerX;
    int integerY = int(y);
    float fractionalY = y-integerY;
    float v1 = SmoothedNoise(integerX, integerY);
    float v2 = SmoothedNoise(integerX+1, integerY);
    float v3 = SmoothedNoise(integerX, integerY+1);
    float v4 = SmoothedNoise(integerX+1, integerY+1); //若x，y的变化不大，则v1v2v3v4不会发生变化
    float i1 = Interpolate(v1, v2, fractionalX);
    float i2 = Interpolate(v3, v4, fractionalX); //采用cosin插值
    return Interpolate(i1, i2, fractionalY);
}


//persistence越接近1，波动越明显；n代表需要叠加的倍频数
float PerlinNoise(float x, float y, float persistence, int n)
{
    float total = 0;
    x = 0.01*x;
    y = 0.01*y;
    if(persistence<0.0 || persistence>1.0)
    {
        return -1;
    }
    for(int i = 0; i < n; i++)
    {
        float frequency = pow(2, i);
        float amplitude = pow(persistence, i);
        total = total + InterpolatedNoise(x*frequency, y*frequency)*amplitude;//frequence越大，起伏越小
    }
    return total;
}

Chunk::Chunk(int x, int z){
    this->x = x;
    this->z = z;
    xNeg = xPos = zNeg = zPos = NULL;
    for(int i = 0; i < 16; i++)
    {
        subChunks[i] = new SubChunk(i*16, x, z);
    }
    if(!readFile(to_string(x)+"_"+to_string(z)))
        generateMap();  //data not exist, then generate
}

Chunk::~Chunk(){
    for(int i = 0; i < 16; i++)
    {
        delete subChunks[i];
    }
}

bool Chunk::generateMap(bool isSea, int seaLevel)
{
    int max = 0;
    for(int i = 0; i < 16; i++)
    {
        for(int j = 0; j < 16; j++)
        {
            height[i][j] = (int)(120+PerlinNoise(x+i, z+j, 0.1, 5)*64);
            if(max < height[i][j])
                max = height[i][j];
        }
    } //the height of soil layer
    maxHeight = max;
    
    
    int heightRock[16][16];
    for(int i = 0; i < 16; i++)
    {
        for(int j = 0; j < 16; j++)
        {
            int tmpHeight = (int)(115+PerlinNoise(x+i, z+j, 0.1, 5)*64);
            if(tmpHeight >= height[i][j]-SOIL_THICKNESS)
                heightRock[i][j] = height[i][j]-SOIL_THICKNESS;
            else
                heightRock[i][j] = tmpHeight;
        }
    } //the height of rock layer
    
    for(int m = 0; m <= maxHeight/16; m++)
    {
        subChunks[m]->isEmpty = false;
        for(int i = 0; i < 16; i++)
        {
            for(int j = 0; j < 16; j++)
            {
                for(int k = 0; k < 16; k++)
                {
                    int tmpHeight = i+m*16;
                    if(tmpHeight > height[j][k])
                    {
                        subChunks[m]->BlockType[i][j][k] = AIR;
                    }
                    else if(tmpHeight > heightRock[j][k])
                    {
                        subChunks[m]->BlockType[i][j][k] = SOIL;
                        subChunks[m]->count++; //只统计非透明砖块
                    }
                    else
                    {
                        subChunks[m]->BlockType[i][j][k] = ROCK;
                        subChunks[m]->count++;
                    }
                }
            }
        }
    }
    //writeFile(to_string(xPos)+"_"+to_string(zPos));
    return true;
}

char* Chunk::readChunk()
{
    char *ret = (char *)malloc(16*16*256*sizeof(char));
    int size = 16*16*16;
    for(int i = 0; i < 16; i++)
        memcpy(ret+i*size, subChunks[i]->BlockType, size*sizeof(char));
    return ret;
}

bool Chunk::readFile(string filePath){
    fstream fin;
    fin.open(filePath,ios::in);
    if(!fin)
        return false;
    else
    {
        //........................
        fin.close();
        return true;
    }
}

bool Chunk::writeFile(string filePath){
    fstream fout;
    fout.open(filePath);
    if(!fout)
        return false;
    else
    {
        //........................
        fout.close();
        return true;
    }
}

inline void Chunk::setCoordinate(int x, int z){
    this->x = x;
    this->z = z;
}

//void ChunkData::draw_chunk(glm::vec3 position, glm::mat4 view, glm::mat4 projection, Shader& Block_Shader, char type) {
//    for(int i = 0; i < 16; i++) {
//
//    }
//}

void Chunk::updateNeighbor(Chunk* xNeg, Chunk* xPos, Chunk* zNeg, Chunk* zPos){
    SubChunk *dir[6];
    
    this->xPos = xPos;
    this->xNeg = xNeg;
    this->zPos = zPos;
    this->zNeg = zNeg;
    
    for(int i = 0; i < 16; i++)
    {
        dir[0] = (xNeg)? xNeg->subChunks[i]: NULL;
        dir[1] = (xPos)? xPos->subChunks[i]: NULL;
        dir[2] = (zNeg)? zNeg->subChunks[i]: NULL;
        dir[3] = (zPos)? zPos->subChunks[i]: NULL;
        dir[4] = (i == 0)? NULL: subChunks[i-1]; //y-
        dir[5] = (i == 15)? NULL: subChunks[i+1]; //y+
        subChunks[i]->updateNeighbor(dir);
    }
}





VisibleChunks::VisibleChunks(float x, float y, float z){
    int ChunkX, ChunkZ;
    int SubChunkIndex;
    
    ChunkX = (ChunkX >= 0)?((int)(x/16))*16:(((int)(x/16))-1)*16;
    ChunkZ = (ChunkZ >= 0)?((int)(z/16))*16:(((int)(z/16))-1)*16;
    SubChunkIndex = (int)(y/16);
    
    for(int i = 0; i < 2*RADIUS+1; i++)
    {
        for(int j = 0; j <2*RADIUS+1; j++)
        {
            int tmpx = ChunkX+(j-RADIUS)*16;
            int tmpz = ChunkZ+(i-RADIUS)*16;
            Chunks[i][j] = new Chunk(tmpx, tmpz);
        }
    }
    curChunk = Chunks[RADIUS][RADIUS];
    curSubChunk = curChunk->subChunks[SubChunkIndex];
    initQuads();
}

void VisibleChunks::initQuads(){
    initNeighbor();
    for(int i = 0; i < 2*RADIUS+1; i++)
    {
        for(int j = 0; j < 2*RADIUS+1; j++)
        {
            for(int k = 0; k < 16; k++)
            {
                Chunks[i][j]->subChunks[k]->updateQuads();
                Chunks[i][j]->subChunks[k]->updateVisibility();
            }
        }
    }
}

void VisibleChunks::initNeighbor(){
    for(int i = 0; i < 2*RADIUS+1; i++)
    {
        for(int j = 0; j < 2*RADIUS+1; j ++)
        {
            Chunk *xNegChunk = (i > 0)? Chunks[i-1][j]: NULL;
            Chunk *xPosChunk = (i < 2*RADIUS)? Chunks[i+1][j]: NULL;
            Chunk *zNegChunk = (j > 0)? Chunks[i][j-1]: NULL;
            Chunk *zPosChunk = (j < 2*RADIUS)? Chunks[i][j+1]: NULL;
            Chunks[i][j]->updateNeighbor(xNegChunk, xPosChunk, zNegChunk, zPosChunk);
        }
    }
}

VisibleChunks::~VisibleChunks(){
    for(int i = 0; i < 2*RADIUS+1; i++)
        for(int j = 0; j < 2*RADIUS+1; j++)
            delete Chunks[i][j];
}

bool VisibleChunks::updataChunks(float x, float y, float z){
    int ChunkX, ChunkZ;
    int SubChunkIndex;
    int dir = NO_DIR;
    
    ChunkX = (ChunkX >= 0)?((int)(x/16))*16:(((int)(x/16))-1)*16;
    ChunkZ = (ChunkZ >= 0)?((int)(z/16))*16:(((int)(z/16))-1)*16;
    SubChunkIndex = (int)(y/16);
    
    curSubChunk = curChunk->subChunks[SubChunkIndex];
    
    if(ChunkX == curChunk->x && ChunkZ == curChunk->z)
        return false;
    else if(ChunkX < curChunk->x) //to left
    {
        for(int i = 0; i < 2*RADIUS+1; i++)
        {
            Chunk *tmp;
            tmp = Chunks[2*RADIUS][i];
            for(int j = 2*RADIUS; j > 0; j--)
            {
                Chunks[j][i] = Chunks[j-1][i];
            }
            
            delete tmp;
            Chunks[0][i] = new Chunk(ChunkX-RADIUS, ChunkZ);
        }
        dir = LEFT;
    }
    else if(ChunkX > curChunk->x) //to right
    {
        for(int i = 0; i < 2*RADIUS+1; i++)
        {
            Chunk *tmp;
            tmp = Chunks[0][i];
            for(int j = 0; j < 2*RADIUS; j++)
            {
                Chunks[j][i] = Chunks[j+1][i];
            }
            
            delete tmp;
            Chunks[2*RADIUS][i] = new Chunk(ChunkX+RADIUS, ChunkZ);
        }
        dir = RIGHT;
    }
    else if(ChunkZ > curChunk->z) //to front
    {
        for(int i = 0; i < 2*RADIUS+1; i++)
        {
            Chunk *tmp;
            tmp = Chunks[i][0];
            for(int j = 0; j < 2*RADIUS; j++)
            {
                Chunks[i][j] = Chunks[i][j+1];
            }

            delete tmp;
            Chunks[i][2*RADIUS] = new Chunk(ChunkX, ChunkZ+RADIUS);
        }
        dir = FRONT;
    }
    else if(ChunkZ < curChunk->z) //to behind
    {
        for(int i = 0; i < 2*RADIUS+1; i++)
        {
            Chunk *tmp;
            tmp = Chunks[i][2*RADIUS];
            for(int j = 2*RADIUS; j > 0; j--)
            {
                Chunks[i][j] = Chunks[i][j-1];
            }
            
            delete tmp;
            Chunks[i][0] = new Chunk(ChunkX, ChunkZ-RADIUS);
        }
        dir = BEHIND;
    }
    curChunk = Chunks[RADIUS][RADIUS];
    if(dir)
        updateQuads(dir);
    return true;
}

void VisibleChunks::updateQuads(int dir){
    updateNeighbor(dir);
    if(dir == LEFT)
    {
        for(int i = 0; i < 2*RADIUS; i++)
        {
            for(int j = 0; j < 16; j++)
            {
                Chunks[1][i]->subChunks[j]->updateQuads(dir);
                Chunks[0][i]->subChunks[j]->updateQuads();
            }
        }
    }
    else if(dir == RIGHT)
    {
        for(int i = 0; i < 2*RADIUS; i++)
        {
            for(int j = 0; j < 16; j++)
            {
                Chunks[2*RADIUS-1][i]->subChunks[j]->updateQuads(dir);
                Chunks[2*RADIUS][i]->subChunks[j]->updateQuads();
            }
        }
    }
    else if(dir == BEHIND)
    {
        
        for(int i = 0; i < 2*RADIUS; i++)
        {
            for(int j = 0; j < 16; j++)
            {
                Chunks[1][i]->subChunks[j]->updateQuads(dir);
                Chunks[0][i]->subChunks[j]->updateQuads();
            }
        }
    }
    else if(dir == FRONT)
    {
        
        for(int i = 0; i < 2*RADIUS; i++)
        {
            for(int j = 0; j < 16; j++)
            {
                Chunks[i][2*RADIUS-1]->subChunks[j]->updateQuads(dir);
                Chunks[i][2*RADIUS]->subChunks[j]->updateQuads();
            }
        }
    }
}

void VisibleChunks::updateNeighbor(int dir){
    if(dir == LEFT)
    {
        for(int i = 0; i < 2*RADIUS; i++)
        {
            Chunks[2*RADIUS][i]->xPos = NULL;
            for(int j = 0; j < 16; j++)
            {
                Chunks[2*RADIUS][i]->subChunks[j]->xPos = NULL;
            }
            
            Chunks[1][i]->xNeg = Chunks[0][i];
            for(int j = 0; j < 16; j++)
            {
                Chunks[1][i]->subChunks[j]->xNeg = Chunks[0][i]->subChunks[j];
            }
            
            Chunk *zNegChunk = (i > 0)? Chunks[0][i-1]: NULL;
            Chunk *zPosChunk = (i < 2*RADIUS)? Chunks[0][i+1]: NULL;
            Chunks[0][i]->updateNeighbor(NULL, Chunks[1][i], zNegChunk, zPosChunk);
        }
    }
    else if(dir == RIGHT)
    {
        for(int i = 0; i < 2*RADIUS; i++)
        {
            Chunks[0][i]->xNeg = NULL;
            for(int j = 0; j < 16; j++)
            {
                Chunks[0][i]->subChunks[j]->xNeg = NULL;
            }
            
            Chunks[2*RADIUS-1][i]->xPos = Chunks[2*RADIUS][i];
            for(int j = 0; j < 16; j++)
            {
                Chunks[2*RADIUS-1][i]->subChunks[j]->xPos = Chunks[2*RADIUS][i]->subChunks[j];
            }
            
            Chunk *zNegChunk = (i > 0)? Chunks[0][i-1]: NULL;
            Chunk *zPosChunk = (i < 2*RADIUS)? Chunks[0][i+1]: NULL;
            Chunks[2*RADIUS][i]->updateNeighbor(Chunks[2*RADIUS-1][i], NULL, zNegChunk, zPosChunk);
        }
    }
    else if(dir == BEHIND)
    {
        for(int i = 0; i < 2*RADIUS; i++)
        {
            Chunks[i][2*RADIUS]->zPos = NULL;
            for(int j = 0; j < 16; j++)
            {
                Chunks[i][2*RADIUS]->subChunks[j]->zPos = NULL;
            }
            
            Chunks[i][1]->zNeg = Chunks[i][0];
            for(int j = 0; j < 16; j++)
            {
                Chunks[i][1]->subChunks[j]->zNeg = Chunks[i][0]->subChunks[j];
            }
            
            Chunk *xNegChunk = (i > 0)? Chunks[i-1][0]: NULL;
            Chunk *xPosChunk = (i < 2*RADIUS)? Chunks[i+1][0]: NULL;
            Chunks[i][0]->updateNeighbor(xNegChunk, xPosChunk, NULL, Chunks[i][1]);
        }
    }
    else if(dir == FRONT)
    {
        for(int i = 0; i < 2*RADIUS; i++)
        {
            Chunks[i][0]->zNeg = NULL;
            for(int j = 0; j < 16; j++)
            {
                Chunks[i][0]->subChunks[j]->zNeg = NULL;
            }
            
            Chunks[i][2*RADIUS-1]->zPos = Chunks[i][2*RADIUS];
            for(int j = 0; j < 16; j++)
            {
                Chunks[i][2*RADIUS-1]->subChunks[j]->zPos = Chunks[i][2*RADIUS]->subChunks[j];
            }
            
            Chunk *xNegChunk = (i > 0)? Chunks[i-1][0]: NULL;
            Chunk *xPosChunk = (i < 2*RADIUS)? Chunks[i+1][0]: NULL;
            Chunks[i][2*RADIUS]->updateNeighbor(xNegChunk, xPosChunk, Chunks[i][2*RADIUS-1], NULL);
        }
    }
}


inline Chunk *VisibleChunks::getCurChunk(){
    return curChunk;
}


inline SubChunk *VisibleChunks::getCurSubChunk(){
    return curSubChunk;
}



void VisibleChunks::getRenderingSubChunks(int y, int x, int z){
    SubChunk* tmp;
    
    //clear
    while(!renderQueue.empty())
        renderQueue.pop();
    clearPathHistory();
    
    scanQueue.push(curSubChunk);
    if(floodFill(y, x, z))
    {
        if(curSubChunk->xNeg != NULL)
            scanQueue.push(curSubChunk->xNeg);
        if(curSubChunk->xPos != NULL)
            scanQueue.push(curSubChunk->xPos);
        if(curSubChunk->zNeg != NULL)
            scanQueue.push(curSubChunk->zNeg);
        if(curSubChunk->zPos != NULL)
            scanQueue.push(curSubChunk->zPos);
        if(curSubChunk->yNeg != NULL)
            scanQueue.push(curSubChunk->yNeg);
        if(curSubChunk->yPos != NULL)
            scanQueue.push(curSubChunk->yPos);
    }
    while(!scanQueue.empty())
    {
        //cout<<scanQueue.size()<<endl;
        tmp = scanQueue.front();
        tmp->adjBlocksEnqueue();
        if(tmp->Quads.size())
            renderQueue.push(tmp);
        scanQueue.pop();
    }
//    return renderQueue;
}


bool VisibleChunks::floodFill(int y, int x, int z){
    class Coordinate{
    public:
        int x;
        int y;
        int z;
        Coordinate(int x, int y, int z){ this->x = x; this->y = y; this->z = z;}
    };
    stack<Coordinate *> s;
    Coordinate *tmp;
    const int offsety[6] = {1, -1, 0, 0, 0, 0};
    const int offsetx[6] = {0, 0, 1, -1, 0, 0};
    const int offsetz[6] = {0, 0, 0, 0, 1, -1};
    int tmpx, tmpy, tmpz;
    
    
    x = x%16;
    if(x < 0)
        x += 16;
    
    y = y%16;//r如果y<0, 需要抛出异常
    
    z = z%16;
    if(z < 0)
        z += 16;
    
    int visited[16][16][16] = {0};
    visited[y][x][z] = 1;
    s.push(new Coordinate(y, x, z));
    
    while(!s.empty())
    {
        tmp = s.top();
        if(tmp->x == 0 || tmp->x == 15 || tmp->y == 0 || tmp->y == 15 ||
           tmp->z == 0 || tmp->z == 15)
        {
            return true;
        }
        else
        {
            int x = tmp->x;
            int y = tmp->y;
            int z = tmp->z;
            for(int i = 0; i < 6; i++)
            {
                tmpx = x+offsetx[i];
                tmpy = y+offsety[i];
                tmpz = z+offsetz[i];
                if((curSubChunk->BlockType[tmpy][tmpx][tmpz] & 0x80) != 0 &&
                   !visited[tmpy][tmpx][tmpz])
                {
                    s.push(new Coordinate(tmpy, tmpx, tmpz));
                    visited[tmpy][tmpx][tmpz] = 1;
                }
            }
        }
        s.pop();
    }
    return false;
}


void VisibleChunks::clearPathHistory(){
    for(int i = 0; i < 2*RADIUS+1; i++)
    {
        for(int j = 0; j < 2*RADIUS+1; j++)
        {
            for(int k = 0; k < 16; k++)
            {
                Chunks[i][j]->subChunks[k]->setPathHistory(NO_DIR);
            }
        }
    }
}

void VisibleChunks::draw(glm::vec3 cameraPos, glm::mat4 view, glm::mat4 projection, Shader& Block_Shader){
    calcFrustumPlane(view, projection);
    getRenderingSubChunks((int)cameraPos.y, (int)cameraPos.x, (int)cameraPos.z);//float为负数时候怎么rounding？？？？
    Block_Shader.use();
    Block_Shader.setMat4("view", view);
    Block_Shader.setMat4("projection", projection);
    SubChunk *tmp;
    for(int i = 0; i < renderQueue.size(); i++)
    {
        tmp = renderQueue.front();
        glBindVertexArray(tmp->bufferObject.getVAO());
        glDrawArrays(GL_TRIANGLE_STRIP, 0, sizeof(tmp->Quads.size())/(8*sizeof(float)));
        renderQueue.pop();
    }
}

void VisibleChunks::calcFrustumPlane(glm::mat4 view, glm::mat4 projection){
    glm::mat4 matrix = projection*view;
    for(int i = 0; i < 6; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            frustumPlanes[i][j] = matrix[3][j]+glm::pow(-1, i)*matrix[i/2][j];
        }
    }//left, right, bottom, top, near, far
}




